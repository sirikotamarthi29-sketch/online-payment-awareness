# PaySafe – Online Payment Awareness CSP Website

This is a responsive static website starter created from the project requirements shared in the conversation.

## How to preview
1. Extract the ZIP file.
2. Open `index.html` in a web browser.
3. For best results, use a local static server or deploy the folder to a static hosting provider.

## Important Wix note
Wix does not normally import a complete HTML/CSS/JS website ZIP as an editable Wix site. This ZIP is a standalone website source package for previewing or deploying to a static host. To build the same site inside Wix, use the master prompt in Wix AI and upload the included college photo.

## Included
- Cover page with college/project/team/mentor details.
- Online Payment Awareness project sections.
- Editable placeholder survey table (no invented results).
- Awareness poster designs and image upload preview.
- Interactive short quiz.
- Final About Ramachandra College of Engineering page.
- Uploaded college building photograph.

## Before academic submission
- Verify the third team member's ID. It was not fully clear in the supplied image and is currently entered as `25MES A0510`.
- Replace survey placeholders with actual survey data.
- Upload official college and APSCHE logos in place of the text placeholders.
- Verify college-specific institutional and facilities information before submission.
- Update project photos and survey findings.

## Folder structure
- `index.html`
- `css/style.css`
- `js/script.js`
- `assets/ramachandra-college.jpg`
- `assets/cover-reference.jpg`


PICTURES ADDED
Four original illustrations are included in assets/: QR payment, successful payment, fraud warning, and secure online shopping. They appear in the Awareness Posters & Gallery section.
